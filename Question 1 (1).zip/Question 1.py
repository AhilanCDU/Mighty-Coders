import zipfile
import os
import pandas as pd # type: ignore

def extract_zip(zip_path, extract_to_folder):
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_to_folder)
    print(f"Extracted ZIP file to: {extract_to_folder}")

def extract_text_from_csv(csv_folder, text_columns, output_file):
    all_texts = ""
    
    for csv_file in os.listdir(csv_folder):
        if csv_file.endswith(".csv"):
            csv_path = os.path.join(csv_folder, csv_file)
            print(f"Processing file: {csv_path}")
            df = pd.read_csv(csv_path)
            
            for text_column in text_columns:
                if text_column in df.columns:
                    texts = df[text_column].dropna().tolist()
                    if texts:
                        print(f"Extracted {len(texts)} texts from column {text_column} in {csv_file}")
                        all_texts += " ".join(texts) + "\n"
                    else:
                        print(f"No text found in column {text_column} of {csv_file}")
                else:
                    print(f"Column {text_column} not found in {csv_file}")
    
    with open(output_file, "w", encoding='utf-8') as f:
        f.write(all_texts)
    print(f"Combined text written to: {output_file}")

# Paths
zip_path = r"C:\Users\Shaun Tidswell\Downloads\Assignment 2.zip"
extract_to_folder = r"C:\Users\Shaun Tidswell\Downloads\Assignment 2"
text_columns = ["SHORT-TEXT", "entites", "TEXT"]
output_file = r"C:\Users\Shaun Tidswell\Downloads\combined_texts.txt"

# Step 1: Extract the ZIP file
extract_zip(zip_path, extract_to_folder)

# Step 2: Extract text from CSV files
extract_text_from_csv(extract_to_folder, text_columns, output_file)

from collections import Counter
import re
import csv

def count_word_occurrences(text_file, output_csv):
    with open(text_file, 'r', encoding='utf-8') as file:
        text = file.read()
    
    words = re.findall(r'\b[a-zA-Z]+\b', text.lower())  # Extract only alphabetic words
    word_counts = Counter(words)
    
    # Get the top 30 most common words
    most_common_words = word_counts.most_common(30)
    
    # Write to CSV file
    import csv
    with open(output_csv, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['Word', 'Count'])
        writer.writerows(most_common_words)

# Example of use
output_csv = r"C:\Users\Shaun Tidswell\Downloads\word_counts.csv"
count_word_occurrences(output_file, output_csv)
