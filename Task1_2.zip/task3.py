import spacy
from transformers import AutoTokenizer, AutoModelForTokenClassification, pipeline
import csv
from collections import Counter
import multiprocessing as mp
import torch  # Import torch for setting default tensor type

# Set default tensor type (if needed)
torch.set_default_dtype(torch.float)  

# Load SpaCy model once
spacy_nlp = spacy.load('en_core_sci_sm')
spacy_nlp.max_length = 2000000

# Load BioBERT model once
tokenizer = AutoTokenizer.from_pretrained('dmis-lab/biobert-base-cased-v1.1', force_download=True)
model = AutoModelForTokenClassification.from_pretrained('dmis-lab/biobert-base-cased-v1.1', force_download=True)
biobert_nlp = pipeline("ner", model=model, tokenizer=tokenizer, aggregation_strategy="simple")

# Perform NER using SpaCy in parallel
def process_spacy_chunks(chunk, max_results=100):
    spacy_doc = spacy_nlp(chunk)
    results = [(ent.text, ent.label_) for ent in spacy_doc.ents if ent.label_ in ["Disease", "Drug"]]
    return results[:max_results]

# Perform NER using BioBERT in parallel
def process_biobert_chunks(chunk, max_results=100):
    biobert_results = biobert_nlp(chunk)
    results = [(ent['word'], ent['entity_group']) for ent in biobert_results if ent['entity_group'] in ["Disease", "Drug"]]
    return results[:max_results]

def task3_ner(input_txt, spacy_output_csv, biobert_output_csv, chunk_size=512, max_results=100):
    with open(input_txt, 'r', encoding='utf-8') as file:
        text = file.read()

    # Chunking text
    chunks = [text[i:i+chunk_size] for i in range(0, len(text), chunk_size)]

    # Parallel processing for SpaCy
    with mp.Pool(mp.cpu_count()) as pool:
        spacy_results = pool.starmap(process_spacy_chunks, [(chunk, max_results) for chunk in chunks])
        spacy_entities = [item for sublist in spacy_results for item in sublist]
    
    # Save SpaCy NER results
    with open(spacy_output_csv, 'w', newline='', encoding='utf-8') as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(["Entity", "Label"])
        writer.writerows(spacy_entities[:max_results])
    print(f"SpaCy NER results saved to {spacy_output_csv}")

    # Parallel processing for BioBERT
    with mp.Pool(mp.cpu_count()) as pool:
        biobert_results = pool.starmap(process_biobert_chunks, [(chunk, max_results) for chunk in chunks])
        biobert_entities = [item for sublist in biobert_results for item in sublist]
    
    # Save BioBERT NER results
    with open(biobert_output_csv, 'w', newline='', encoding='utf-8') as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(["Entity", "Label"])
        writer.writerows(biobert_entities[:max_results])
    print(f"BioBERT NER results saved to {biobert_output_csv}")

def task3_top_30_unique_tokens(input_txt, output_csv, top_n=30, chunk_size=1000):
    tokenizer = AutoTokenizer.from_pretrained('dmis-lab/biobert-base-cased-v1.1', force_download=True)
    
    tokens = []
    with open(input_txt, 'r', encoding='utf-8') as file:
        while True:
            chunk = file.read(chunk_size)
            if not chunk:
                break
            chunk_tokens = tokenizer.tokenize(chunk)
            tokens.extend(chunk_tokens)

    token_count = Counter(tokens)
    top_tokens = token_count.most_common(top_n)
    
    with open(output_csv, 'w', newline='', encoding='utf-8') as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(["Token", "Count"])
        writer.writerows(top_tokens)
    
    print(f"Top {top_n} unique tokens saved to {output_csv}")

if __name__ == '__main__':
    # Paths to input and output files
    input_txt = 'output.txt'
    spacy_output_csv = 'spacy_ner_results.csv'
    biobert_output_csv = 'biobert_ner_results.csv'
    token_csv = 'top_tokens.csv'

    # Task 3.1: Perform NER using SpaCy and BioBERT
    task3_ner(input_txt, spacy_output_csv, biobert_output_csv, chunk_size=512, max_results=100)

    # Task 3.2: Count unique tokens using AutoTokenizer
    task3_top_30_unique_tokens(input_txt, token_csv, top_n=30)
