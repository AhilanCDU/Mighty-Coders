import spacy
from transformers import AutoTokenizer, AutoModelForTokenClassification, pipeline
import csv
from collections import Counter

# Load the SpaCy model for NER
def load_spacy_model():
    nlp = spacy.load('en_core_sci_sm')
    nlp.max_length = 2000000  
    return nlp

# Load the BioBERT model for NER
def load_biobert_model():
    tokenizer = AutoTokenizer.from_pretrained('dmis-lab/biobert-base-cased-v1.1', force_download=True)
    model = AutoModelForTokenClassification.from_pretrained('dmis-lab/biobert-base-cased-v1.1', force_download=True)
    nlp = pipeline("ner", model=model, tokenizer=tokenizer, aggregation_strategy="simple")
    return nlp

# Task 4: Perform Named-Entity Recognition (NER) using SpaCy and BioBERT, and compare results
def task4_ner_comparison(output_txt, csv_save_location_spacy, csv_save_location_biobert):
    spacy_nlp = load_spacy_model()
    biobert_nlp = load_biobert_model()

    with open(output_txt, 'r', encoding='utf-8') as file:
        text_input = file.read()

    # Define chunk size 
    chunk_size = 512  # Tokens
    tokenizer = AutoTokenizer.from_pretrained('dmis-lab/biobert-base-cased-v1.1', force_download=True)
    text_chunks = [text_input[i:i + chunk_size * 2] for i in range(0, len(text_input), chunk_size * 2)]  # Approx 2 tokens per char

    spacy_entities = []
    biobert_entities = []

    # Process each chunk separately
    for chunk in text_chunks:
        # Perform NER with SpaCy
        doc = spacy_nlp(chunk)
        spacy_entities.extend([ent.text for ent in doc.ents if ent.label_ in ["Disease", "Drug"]])

        # Perform NER with BioBERT
        biobert_results = biobert_nlp(chunk)
        biobert_entities.extend([ent['word'] for ent in biobert_results if ent['entity_group'] in ["Disease", "Drug"]])

    # Limit entities to a reasonable number 
    spacy_entities = spacy_entities[:500]
    biobert_entities = biobert_entities[:500]

    # Count occurrences of entities
    spacy_counter = Counter(spacy_entities)
    biobert_counter = Counter(biobert_entities)

    # Save SpaCy entities to a CSV file
    with open(csv_save_location_spacy, 'w', newline='', encoding='utf-8') as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(["Entity", "Count"])  # Header
        writer.writerows(spacy_counter.items())

    # Save BioBERT entities to a CSV file
    with open(csv_save_location_biobert, 'w', newline='', encoding='utf-8') as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(["Entity", "Count"])  # Header
        writer.writerows(biobert_counter.items())

    print(f"Entities extracted and saved:\n - SpaCy: {csv_save_location_spacy}\n - BioBERT: {csv_save_location_biobert}")

# Testing the code
output_txt = 'output.txt'
csv_save_location_spacy = 'spacy_entities.csv'
csv_save_location_biobert = 'biobert_entities.csv'

# Run NER comparison
task4_ner_comparison(output_txt, csv_save_location_spacy, csv_save_location_biobert)
