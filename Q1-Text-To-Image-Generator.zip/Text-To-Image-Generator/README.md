# Text-To-Image-Generator

> This project uses the Stable Diffusion Pipeline to generate images from text prompts. 

## Getting Started

To get started, you will need to have a GPU and install the following dependencies:

- PyTorch
- diffusers
- matplotlib

### Prerequisites

Before running this application, you will need to have the following installed:

You can install these dependencies using pip. For example:

```
pip install tkinter
```
```
pip install customtkinter
```
```
pip install diffusers
```
```
pip install torch
```
```
pip install Pillow
```

python imagegenerator.py
```

## License

This project is licensed under the MIT License
