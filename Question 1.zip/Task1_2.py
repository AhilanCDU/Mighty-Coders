import pandas as pd
from collections import Counter
import csv
import re  # For regex filtering

# Helper function to clean text by removing numbers and symbols, keeping only alphabetic characters
def clean_text(text):
    return re.sub(r'[^a-zA-Z\s]', '', text)

# Task 1: Extract text from all CSV files and save to a single .txt file
def task1_extract_text_csv_txt(input_csv_files, output_txt, batch_size=1000):
    with open(output_txt, 'w', encoding='utf-8') as f: 
        pass
    
    for csv_file_location in input_csv_files:
        dataset_df = pd.read_csv(csv_file_location, chunksize=batch_size)  # Process in chunks
        for chunk in dataset_df:
            # Find columns containing 'text' in their name (case insensitive)
            text_column = chunk.columns[chunk.columns.str.contains('text', case=False, regex=True)]
            if not text_column.empty:
                text_data = chunk[text_column[0]].dropna().tolist()
                cleaned_text_data = [clean_text(text) for text in text_data]  # Clean text
                with open(output_txt, 'a', encoding='utf-8') as f:
                    f.write("\n".join(cleaned_text_data) + "\n")  # Write each chunk of cleaned text to the output file
    print(f"Text extraction completed. File saved at: {output_txt}")

# Task 2: Find the top 30 most common words and save to a CSV file
def task2_top_30_common_words(output, csv_save_location, top_n=30):
    with open(output, 'r', encoding='utf-8') as file:
        text_input = file.read()
    
    words = text_input.split()
    words_count = Counter(words)
    top_30_common_words = words_count.most_common(top_n)
    
    with open(csv_save_location, 'w', newline='', encoding='utf-8') as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(["Word", "Count"])  # Header
        writer.writerows(top_30_common_words)

    print(f"Top {top_n} common words saved to {csv_save_location}")

# Main Execution
if __name__ == '__main__':
    # Task 1: Extract text from CSV files
    input_csv_files = ['CSV1.csv', 'CSV2.csv', 'CSV3.csv', 'CSV4.csv'] 
    output_txt = 'output.txt'
    task1_extract_text_csv_txt(input_csv_files, output_txt)

    # Task 2: Find the top 30 most common words
    csv_save_location = 'top_30_common_words.csv'
    task2_top_30_common_words(output_txt, csv_save_location, top_n=30)
