# Part 1
def string(s):
    # Initialize the two substrings.
    numbers = ''
    letters = ''

    # Using for loop to separate the numbers and letters.
    for char in s:
        if char.isdigit():
            numbers = numbers + char
        elif char.isalpha():
            letters = letters + char

    # Extracting the even numbers from number string.
    even = []
    for num in numbers:
        n = int(num)
        if n % 2 == 0:
            even.append(n)

    # Converting the even numbers to ASCII codes.
    even_ascii = []
    for num in even:
        ascii = ord(str(num))
        even_ascii.append(ascii)

    # Extracting uppercase letters from letter string.
    uppercase = []
    for l in letters:
        if l.isupper():
            uppercase.append(l)

    # Converting the uppercase letters to ASCII codes.
    uppercase_ascii = []
    for l in uppercase:
        ascii_l = ord(l)
        uppercase_ascii.append(ascii_l)

    return even_ascii, uppercase_ascii


# Input the value of s.
s = '56aAww1984sktr235270aYmn145ss785fsq31D0'

even_ascii, uppercase_ascii = string(s)

# Output
print(f"ASCII codes of even numbers: {even_ascii}")
print(f"ASCII codes of uppercase letters: {uppercase_ascii}\n")

# Part 2
def caesar_cipher(t, shift):
    result = ""

    # Traversing the text.
    for char in t:
        # Checking if the character is an uppercase letter.
        if char.isupper():
            # Shift the character when required.
            result = result + chr((ord(char) + shift - 65) % 26 + 65)
        # Checking if the character is a lowercase letter.
        elif char.islower():
            # Shift the character when required.
            result = result + chr((ord(char) + shift - 97) % 26 + 97)
        else:
            result = result + char

    return result


# The given sentence in the question.
sen = "Many newspapers publish a cryptogram each day."

# Encoding the sentence with a shift of 3 characters.
shift = 3
encoded_sen = caesar_cipher(sen, shift)
print(f"The encoded sentence ---> {encoded_sen}")

# Decoding the sentence to the original one.
decoded_sen = caesar_cipher(encoded_sen, -shift)
print(f"The decoded sentence ---> {decoded_sen}")
