from PIL import Image
import time

# Generating the number 'n'.
current_time = int(time.time())

n = (current_time % 100) + 50

if n % 2 == 0:
    n = n + 10

print("The number generated is ", n)

# Loading the image.
inp_image = 'chapter1.jpg'
out_image = 'chapter1out.png'
current_image = Image.open(inp_image)

# Converting current_image to RGB.
current_image = current_image.convert('RGB')
pixels = current_image.load()

# Get the dimensions of the image to process the pixels.
width, height = current_image.size

# Initialize the sum of red pixels.
s = 0

# Processing each and every pixel in the current_image.
for x in range(width):
    for y in range(height):
        r, g, b = pixels[x, y]

# Adding the generated number `n` to each rgb values.
        red = r + n
        green = g + n
        blue = b + n

# Making sure that the rgb values are within valid range(0-255).
        red = min(max(red, 0), 255)
        green = min(max(green, 0), 255)
        blue = min(max(blue, 0), 255)

# Updating the pixel value.
        pixels[x, y] = (red, green, blue)

# Add the value of red to the sum.
        s = s + red

# Save the modified image.
current_image.save(out_image)

# Output of the sum of red pixels.
print(f"The sum of all red pixels in the new image is {s}")